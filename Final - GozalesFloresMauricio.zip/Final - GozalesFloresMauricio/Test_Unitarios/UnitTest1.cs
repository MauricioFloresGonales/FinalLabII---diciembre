using Entidades;
using System.Net.Http.Headers;

namespace Test_Unitarios
{
    [TestClass]
    public class UnitTest1
    {

        // APELLIDO . NOMBRE
        [TestClass]
        public class Entidades_Debe
        {
            [TestMethod]
            public void InflarTodosLosObjetos()
            {
                #region Consigna 
                /*
                   Crear una lista de IInflable con autos,motos y pelotas desinflados
                   Inflar todos los objetos.
                   Verificar que todos quedan inflados.
                 */

                List<IInflable> lista = new List<IInflable>();

                lista.Add(new Auto(1, "ASD"));
                lista.Add(new Moto(1, "ASD"));
                lista.Add(new Pelota(1));

                int lenght = lista.Count;

                int totalEsperado = 3;

                Assert.AreEqual(totalEsperado, lenght);
                #endregion


            }

            [TestMethod]
            [ExpectedException(typeof(ExplotaException))]
            public void LanzarExplotaException()
            {
                #region Consigna
                /*
                 si pelota excede la presion maxima soportada por ella, 
                 debe lanzar la excepcion ExplotaException
                 notificando que exploto.
                 */

                Pelota pelota = new Pelota(20);

                float presionInflado = 45; //un numero mas al permitido por la presion maxima

                pelota.Inflar(presionInflado);
                #endregion

            }

            [TestMethod]
            public void SerializarObjetosInflables()
            {
                #region Consigna
                /*
                   serializar una la pelota a json y la lista de vehiculos (al menos 2) a xml  o Json
                 */

                List<Pelota> listaPelotas = new List<Pelota>();
                listaPelotas.Add(new Pelota(12));
                listaPelotas.Add(new Pelota(20));
                List<Moto> listaVehiculos = new List<Moto>();
                listaVehiculos.Add(new Moto(12,"ASD"));
                listaVehiculos.Add(new Moto(20,"QWE"));
                //Archivos.Serializar(listaVehiculos);
                //Archivos.Serializar(listaPelotas);


                #endregion


            }

            [TestMethod]
            public void InsertarYLeerDatosDB()
            {
                #region Consigna
                /*
                   crear un Auto, guardarlo en la base de datos
                   volver a obtener el registro de la base y comparar que su informacion sea la enviada
                */

                Auto auto = new Auto(20, "ASD");

                ManejadorSql.InsertarVehiculo(auto);

                List<Auto> listaDeAutos = ManejadorSql.ObtenerAutos();

                Auto autoBD = listaDeAutos.First();

                Assert.AreEqual(auto, autoBD);

                #endregion


            }

            [TestMethod]
            public void RepararUnAuto()
            {
                #region Consigna
                /* 
                  El metodo Reparar del taller debe recibir un objeto de tipo auto y repararlo.

                  Cuando un auto se repara, se hacen dos procesos al mismo tiempo:
                  mientras se inflan las cubiertas, tambien se le repara la mecanica.
                  Inflar una cubierta tarda 3 segundos, y reparar la mecanica 7 segundos
                  No se da por terminada la reparacion hasta que ambos procesos terminen

                  Comprobar que el auto esta inflado y reparado.
                 */
                Auto auto = new Auto(300, "ASD");

                auto.Reparar();

                Assert.AreEqual(true, (auto.EstaInflado && auto.EstaReparado));


                #endregion

            }

            [TestMethod]
            public void Parametrizacion()
            {
                #region Consigna
                /* 
                   Generar un metodo estatico,generico y parametrizado en Taller llamado UtilizarInflador
                   que reciba un elemento del tipo T (restringir que sea de tipo IInflable)
                   Crear dos objetos de tipo IInflable e inflarlos.
                   Verificar que ambos estan inflados.
                */
                #endregion


            }

            [TestMethod]
            public void ExpresionLamda()
            {
                #region Consigna
                /* 
                  Hacer una expresion lambda que retorne de la lista de vehiculos 
                  solo los que tengan menor presion a 20 de presion de inflado

                 Verificar que todos los devueltos tienen presion de inflado menor a 20.
                */
                #endregion
                List<Vehiculo> listaDeVehiculosSeleccionados = new List<Vehiculo>();
                listaDeVehiculosSeleccionados.Add(new Auto(10, "ASD"));
                listaDeVehiculosSeleccionados.Add(new Auto(200, "QWE"));
                listaDeVehiculosSeleccionados.Add(new Auto(5, "ZXC"));

                bool retorno = false;
                var delegado = () =>
                {
                    List<Vehiculo> listaContenedora = new List<Vehiculo>();
                    foreach (Vehiculo item in listaDeVehiculosSeleccionados)
                    {
                        if (item.PresionInflado < 20)
                        {
                            listaContenedora.Add(item);
                        }
                    }
                    return listaContenedora;
                };
                List<Vehiculo> listaDeVehiculos = delegado.Invoke();

                foreach (Vehiculo item in listaDeVehiculos)
                {
                    if (item.PresionInflado < 20)
                    {
                        retorno = true;
                    } else
                    {
                        retorno = false;
                        break;
                    }
                }
                Assert.AreEqual(true, retorno);
            }

            [TestMethod]
            [ExpectedException(typeof(RuedaEnLLantaException))]
            public void CapturarEventoRuedaEnLLanta()
            {

                #region Consigna
                /* 
                   Cada vez que una moto circula, pierde 10 unidades de presion de inflado. 

                Al llegar a 0 o menos su presion de inflado
                deber� ejecutarse un evento. 
                Dicho evento lo que har� es setear la moto como no reparada y 
                tambien lanzar� una excepcion de tipo
                rueda en llanta.

                Comprobar que la excepcion se lanza correctamente,que la presion de la rueda queda en 0,
                y que la moto no queda reparada.
                 */
                #endregion
                Moto m = new Moto(10, "ADDA");
                m.MotoEvento += m.DejarDeCircular;

                m.MotoEvento += () => throw new RuedaEnLLantaException("moto no reparada");
                
                m.CircularVehiculo();



                //Assert.AreEqual(false, m.EstaInflado);
            }

        }
    }
}