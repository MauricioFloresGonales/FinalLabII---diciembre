﻿namespace Entidades
{
    public static class ExtensionCommand
    {
    }
}
