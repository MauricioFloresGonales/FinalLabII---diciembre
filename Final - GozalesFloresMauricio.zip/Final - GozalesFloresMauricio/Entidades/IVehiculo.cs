﻿namespace Entidades
{
    public interface IVehiculo
    {
        void CircularVehiculo();
        bool EstaReparado { get; set; }

    }
}
