﻿namespace Entidades
{
    public delegate void MotoNoReparada();
    public class Moto : Vehiculo, IInflable
    {
        public event MotoNoReparada MotoEvento;
        bool chequeado;

        public Moto(float presionInflado, string patente) : base(presionInflado, 200, patente)
        {

        }

        public Moto() : base()
        {

        }

        public void DejarDeCircular()
        {
            this.estaInflado = false;
            this.presionInflado = 0;
        }



        public bool EstaInflado { get => base.estaInflado; set => base.estaInflado = value; }
        public bool EstaReparado { get => base.estaReparado; set => base.estaReparado = value; }

        public override void CircularVehiculo()
        {
            this.presionInflado -= 10;
            if (this.presionInflado <= 0)
            {
                MotoEvento.Invoke();
            }
           
        }

        public void Reparar()
        {
            this.estaReparado = true;
        }
    }
}
