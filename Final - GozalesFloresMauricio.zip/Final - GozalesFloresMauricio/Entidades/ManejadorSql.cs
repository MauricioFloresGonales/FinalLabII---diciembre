﻿using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace Entidades
{

    public static class ManejadorSql
    {
        static private SqlConnection miConexion;
        static private SqlCommand consulta;

        static ManejadorSql()
        {
            ManejadorSql.miConexion = new SqlConnection();
            ManejadorSql.consulta = new SqlCommand();
            miConexion.ConnectionString = "Data Source = .; Database = BaseDeDatos; Trusted_Connection=true;";
            ManejadorSql.consulta.CommandType = System.Data.CommandType.Text;
            ManejadorSql.consulta.Connection = ManejadorSql.miConexion;
        }

        public static List<Auto> ObtenerAutos()
        {
            try
            {
                ManejadorSql.consulta.CommandText = "SELECT * FROM Autos";

                if (miConexion.State != System.Data.ConnectionState.Open)
                {
                    miConexion.Open();
                }

                SqlDataReader datos = ManejadorSql.consulta.ExecuteReader();
                List<Auto> listaDeAutos = new List<Auto>();

                while (datos.Read())
                {
                    Auto dato = new Auto(
                        int.Parse(datos["presionInflado"].ToString()),
                        datos["patente"].ToString()
                        );


                    listaDeAutos.Add(dato);
                }
                return listaDeAutos;
            }
            catch (Exception ex)
            {
                throw new Exception($"Ocurrio un error al cargar los Alumnos\n{ex.Message}"); ;
            }
            finally
            {
                if (miConexion.State != System.Data.ConnectionState.Closed)
                {
                    miConexion.Close();
                }
            }
        }

        public static bool InsertarVehiculo(Vehiculo vehiculo)
        {
            try
            {
                ManejadorSql.consulta.CommandText = "INSERT INTO Autos VALUES(@presionInflado, @patente)";
                ManejadorSql.consulta.Parameters.Clear();
                ManejadorSql.consulta.Parameters.Add(new SqlParameter("@presionInflado", vehiculo.PresionInflado));
                ManejadorSql.consulta.Parameters.Add(new SqlParameter("@patente", vehiculo.Patente));

                if (miConexion.State != System.Data.ConnectionState.Open)
                {
                    miConexion.Open();
                }
                
                int objInsertados = ManejadorSql.consulta.ExecuteNonQuery();

                if (objInsertados > 0)
                {
                    return true;
                }
                return false;
            }
            catch (Exception ex)
            {
                throw new Exception($"Ocurrio un error al cargar los Autos\n{ex.Message}"); ;
            }
            finally
            {
                if (miConexion.State != System.Data.ConnectionState.Closed)
                {
                    miConexion.Close();
                }
            }
        }

    }
}
