﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using System.Xml.Serialization;

namespace Entidades
{

    public static class ClaseSerializadora<T>
    {
      

    }
}
